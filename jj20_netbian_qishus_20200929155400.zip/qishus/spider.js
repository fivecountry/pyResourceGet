function spiderRun(parseName,response)
{
   pyimport os;
   pyimport uiUtil;

   if (parseName == 'main'){
     //创建请求对象
     var nextObj = uiUtil.spider.RequestInfo();
     //详细页列表
     var detailList = uiUtil.spider.spidertool.resolveXPath(response,'//span[@class="mainSoftName"]/a[contains(@href,"txt/")]/@href');
     //写入地址列表(请求类型(request,follow)，解析标识,地址列表)
     //request=这个类型适用于绝对地址，比如:http://xxx.com/x.html
     //follow=这个类型适用于相对地址，比如:xxx/x.html
     nextObj.putUrl('follow','detail',detailList);
     //下一页
     var nextPages = uiUtil.spider.spidertool.resolveXPath(response,'//dfn/a[contains(text(),"下一页")]/@href');
     if (detailList != null && detailList.length >= 1)
     {
         //打印日志
         uiUtil.spider.spidertool.printLog('小说数量:' + detailList.length);
         //打印日志
         uiUtil.spider.spidertool.printLog('==================');
         //打印日志
         uiUtil.spider.spidertool.printLog('下一页：' + nextPages[0]);	 
	 //写入地址列表(请求类型(request,follow)，解析标识,地址列表)
	 //request=这个类型适用于绝对地址，比如:http://xxx.com/x.html
	 //follow=这个类型适用于相对地址，比如:xxx/x.html
         nextObj.putUrl('follow','main',nextPages);
         //搜索下一页
         return uiUtil.spider.spidertool.requestPage(nextObj);
      }else
      {
         //报告操作完成
         uiUtil.spider.spidertool.reportFinish();
         //没有下一页了
         return uiUtil.spider.spidertool.noPage();
      }
   }else if (parseName == 'detail'){
     var txtList = uiUtil.spider.spidertool.resolveXPath(response,'//div[@class="story"]/div[@id="downAddress"]/a[@rel="nofollow"][contains(@href,"txt")]/@href');
     //创建下载项记录，(远程地址，目标目录名，目标文件名）
     var urll = txtList[0];
     var dObj = uiUtil.spider.SpiderDownloadItem(urll,"all",os.path.basename(urll));
     //向程序反馈下载地址
     uiUtil.spider.spidertool.reportDownloadUrl(dObj);
     //没有下一页了
     return uiUtil.spider.spidertool.noPage();
   }  
}
