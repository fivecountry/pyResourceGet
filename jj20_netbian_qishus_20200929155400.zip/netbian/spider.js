function spiderRun(parseName,response)
{
   pyimport os;
   pyimport uiUtil;
   //取图片地址
   var imgList = uiUtil.spider.spidertool.resolveXPath(response,'//img/@src');
   //生成保存地址
   var destPath = os.path.join(uiUtil.envs.cfenv.dataDir, 'imgUrls.txt');
   //切换需要执行的代码
   if (parseName == 'main'){
      //要输出到文件的缓存
      var outputResult = '';
      //符合要求的下载地址
      var newImgList = [];
      var rIndex = 0;
      //写入图片地址
      for(var vIndex in imgList)
      {
         var vv = imgList[vIndex]
         if (vv.indexOf('/upload') >= 0){
	     var urll = 'http://pic.netbian.com' + vv;
             //outputResult  = outputResult + urll + '\n';
	     //创建下载项记录，(远程地址，目标目录名，目标文件名）
             var dObj = uiUtil.spider.SpiderDownloadItem(urll,"all",os.path.basename(urll));
             newImgList[rIndex] = dObj;
             rIndex++;
         }
      }
      //向程序反馈下载地址
      uiUtil.spider.spidertool.reportDownloadUrl(newImgList);
      //写文件
      //uiUtil.globaltool.iotool.appendText(destPath,outputResult);
      //打印日志
      uiUtil.spider.spidertool.printLog('图片数量:' + imgList.length);

      //查下一页地址
      var nextPages = uiUtil.spider.spidertool.resolveXPath(response,'//a[contains(text(),"下一页") and contains(@href,"index_")]/@href');
      if (nextPages != null && nextPages.length >= 1)
      {
         //打印日志
         uiUtil.spider.spidertool.printLog('==================');
         //打印日志
         uiUtil.spider.spidertool.printLog('下一页：' + nextPages[0]);
	 //创建请求对象
	 var ttt = uiUtil.spider.RequestInfo();
	 //写入地址列表(请求类型(request,follow)，解析标识,地址列表)
	 //request=这个类型适用于绝对地址，比如:http://xxx.com/x.html
	 //follow=这个类型适用于相对地址，比如:xxx/x.html
         ttt.putUrl('follow','main',nextPages);
         //搜索下一页
         return uiUtil.spider.spidertool.requestPage(ttt);
      }else
      {
         //报告操作完成
         uiUtil.spider.spidertool.reportFinish();
         //没有下一页了
         return uiUtil.spider.spidertool.noPage();
      }      
   }
}
