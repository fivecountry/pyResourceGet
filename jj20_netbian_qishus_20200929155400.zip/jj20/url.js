function getUrls()
{
   return ['http://www.jj20.com/bz/nxxz/'];
}
