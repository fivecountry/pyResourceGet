function spiderRun(parseName,response)
{
   pyimport os;
   pyimport uiUtil;
   //取图片地址
   var imgList = uiUtil.spider.spidertool.resolveXPath(response,'//img/@src');
   //生成保存地址
   var destPath = os.path.join(uiUtil.envs.cfenv.dataDir, 'imgUrls.txt');
   //切换需要执行的代码
   if (parseName == 'main'){
      //取旧数据用于叠加
      var outputResult = uiUtil.globaltool.iotool.readAllText(destPath);
      //写入图片地址
      for(var vIndex in imgList)
      {
         var vv = imgList[vIndex]
         if (vv.indexOf('/upload') >= 0){
	     var urll = 'http://pic.netbian.com' + vv;
             outputResult  = outputResult + urll + '\n';
             uiUtil.spider.spidertool.reportDownloadUrl(urll);
         }
      }      
      uiUtil.globaltool.iotool.writeAllText(destPath,outputResult);
      uiUtil.spider.spidertool.printLog('图片数量:' + imgList.length);

      //查下一页地址
      var nextPages = uiUtil.spider.spidertool.resolveXPath(response,'//a[contains(text(),"下一页") and contains(@href,"index_")]/@href');
      if (nextPages != null && nextPages.length >= 1)
      {
         uiUtil.spider.spidertool.printLog('==================');
         uiUtil.spider.spidertool.printLog('下一页：' + nextPages[0]);
         return uiUtil.spider.spidertool.followPage('main',nextPages);
      }else
      {
         uiUtil.spider.spidertool.reportFinish();
         return uiUtil.spider.spidertool.noPage();
      }      
   }
}
